import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

class music():
    def __init__(self):
        service = Service('/opt/homebrew/bin/chromedriver')
        self.driver = webdriver.Chrome(service=service)

    def play(self, query):
        self.query = query
        self.driver.get(f"https://www.youtube.com/results?search_query={query}")
        video = self.driver.find_element("xpath", '//*[@id="video-title"]')
        video.click()
        time.sleep(120)

# assist = music()
# assist.play('yshodara kavi')
