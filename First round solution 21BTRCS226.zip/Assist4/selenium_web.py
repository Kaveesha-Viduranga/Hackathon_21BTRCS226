import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

class InfoW:
    def __init__(self):
        service = Service('/opt/homebrew/bin/chromedriver')  # Path to your ChromeDriver
        self.driver = webdriver.Chrome(service=service)

    def get_info(self, query):
        self.query = query
        self.driver.get("https://www.wikipedia.org")
        print(f"Searching for: {self.query}")

        search_box = self.driver.find_element(By.XPATH, '//*[@id="searchInput"]')  # Corrected XPath
        search_box.click()
        search_box.send_keys(query)

        search_button = self.driver.find_element(By.XPATH, '//*[@id="search-form"]/fieldset/button')
        search_button.click()

        time.sleep(5)  # To keep the browser open for a while


