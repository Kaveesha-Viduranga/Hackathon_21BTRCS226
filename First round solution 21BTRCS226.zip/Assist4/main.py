import pyttsx3 as p
import speech_recognition as sr
import sounddevice as sd
from selenium_web import *
from yt_web import *
from news import *
import randfacts
from jokes import *
from weather import *
import datetime

#print(sd.query_devices())


engine = p.init()
rate=engine.getProperty('rate')
engine.setProperty('rate',160)
voices=engine.getProperty('voices')
#engine.setProperty('voice',voices[50].id)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def wishme():
    hour=int(datetime.datetime.now().hour)
    if hour>0 and hour<12:
        return ("morning")
    elif hour>=12 and hour<16:
        return ("afternoon")
    else:
        return ("evening")

today_date=datetime.datetime.now()
r = sr.Recognizer()
sr.AudioFile.FLAC_CONVERTER = "/usr/local/bin/flac"

speak("hello sir, good " + wishme() +", i'm your voice assistant")
speak("today is " + today_date.strftime("%d") + today_date.strftime("%B") + " and its currently " + (today_date.strftime("%I")) +" "+ (today_date.strftime("%M")) + (today_date.strftime("%p")) )
speak("Temperature in Colombo is " + str(temp()) + "degrees celcius and with " + str(des()))
speak("How are you?")
with sr.Microphone() as source:
    r.energy_threshold=100000
    r.adjust_for_ambient_noise(source,1.2)
    print("listening")
    audio = r.listen(source)
    text = r.recognize_google(audio)
    print(text)

if "what" and "about" and "you" in text:
    speak("i am doing good sir")
speak("how can i help you?")


with sr.Microphone() as source:
    r.energy_threshold=10000
    r.adjust_for_ambient_noise(source,1.2)
    print("listening...")
    audio = r.listen(source)
    text2 = r.recognize_google(audio)

if "information" in text2:
    speak("you need information related to which topic?")
    with sr.Microphone() as source:
        r.energy_threshold = 10000
        r.adjust_for_ambient_noise(source, 1.2)
        print("listening...")
        audio = r.listen(source)
        infor = r.recognize_google(audio)
    speak("searching {} in wikipedia".format(infor))
    print("searching {} in wikipedia".format(infor))
    assist = InfoW()
    assist.get_info(infor)

elif "play" and "video" in text2:
    speak("which video you want to play?")
    with sr.Microphone() as source:
        r.energy_threshold = 10000
        r.adjust_for_ambient_noise(source, 1.2)
        print("listening...")
        audio = r.listen(source)
        vid = r.recognize_google(audio)
    print("Playing {} on youtube".format(vid))
    speak("Playing {} on youtube".format(vid))
    assist = music()
    assist.play(vid)

elif "news" in text2:
    print("Sure sir, Now I will read news for you.")
    speak("Sure sir, Now I will read news for you.")
    arr=news()
    for i in range(len(arr)):
        print(arr[i])
        speak(arr[i])

elif "fact" in text2 or "facts" in text2:
    speak("sure sir, ")
    x=randfacts.get_fact()
    print(x)
    speak("Did you know that, "+x)

elif "joke" in text2:
    speak("sure sir, get ready for some chuckles")
    ar=joke()
    print(ar[0])
    speak(ar[0])
    print(ar[1])
    speak(ar[1])